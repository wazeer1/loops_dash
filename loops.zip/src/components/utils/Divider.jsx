import React from 'react'

const Divider = () => {
  return (
    <div className='w-full h-[1px] bg-slate-300 rounded-lg' />
    
  )
}

export default Divider
