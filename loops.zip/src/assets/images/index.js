import LoginBg from "./loginbg.png";
import LightLogo from "./light-logo.svg";
import DarkLogo from "./dark-logo.svg";

export { LoginBg, DarkLogo, LightLogo };
