import AvatarImage from './avatar.jpg'

export {AvatarImage}